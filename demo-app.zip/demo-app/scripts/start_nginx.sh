#!/bin/bash

sudo service nginx start